#dicky = {'0': [0, 0.0589844, 0.5375, 0.116406, 0.308333], '1': [0, 0.103125, 0.597222, 0.0640625, 0.294444], '2': [26, 0.197656, 0.744444, 0.0703125, 0.155556], '3': [26, 0.471484, 0.615278, 0.0257812, 0.0722222], '4': [5, 0.571875, 0.408333, 0.0484375, 0.141667], '5': [0, 0.388281, 0.532639, 0.046875, 0.234722], '6': [2, 0.725781, 0.502083, 0.090625, 0.165278], '7': [2, 0.664062, 0.479167, 0.05, 0.116667], '8': [0, 0.630469, 0.507639, 0.0296875, 0.168056], '9': [0, 0.059375, 0.700694, 0.11875, 0.579167], '10': [0, 0.167578, 0.645833, 0.0851562, 0.480556], '11': [5, 0.639453, 0.405556, 0.113281, 0.197222], '12': [0, 0.336328, 0.586806, 0.0757812, 0.348611], '13': [0, 0.252344, 0.607639, 0.0609375, 0.370833], '14': [0, 0.439844, 0.561806, 0.071875, 0.359722], '15': [7, 0.878906, 0.497917, 0.240625, 0.443056], '16': [0, 0.501172, 0.567361, 0.0617188, 0.329167]}


#dicks = {'0': [0, 0.0401163, 0.419721, 0.0337209, 0.158813], '1': [0, 0.388953, 0.621291, 0.0732558, 0.352531], '2': [24, 0.760465, 0.746946, 0.0906977, 0.443281], '3': [0, 0.53314, 0.505236, 0.0709302, 0.144852], '4': [0, 0.140698, 0.542757, 0.055814, 0.226876], '5': [24, 0.488372, 0.755672, 0.106977, 0.26178], '6': [0, 0.645349, 0.486911, 0.0627907, 0.132635], '7': [0, 0.82093, 0.468586, 0.0581395, 0.256545], '8': [0, 0.194767, 0.612565, 0.0569767, 0.324607], '9': [0, 0.506395, 0.769634, 0.136047, 0.404887], '10': [24, 0.677907, 0.777487, 0.0976744, 0.204188], '11': [0, 0.783721, 0.552356, 0.0604651, 0.22164], '12': [0, 0.749419, 0.747818, 0.103488, 0.47993], '13': [0, 0.102326, 0.594241, 0.072093, 0.169284], '14': [26, 0.279651, 0.676265, 0.0732558, 0.197208], '15': [0, 0.875, 0.589005, 0.077907, 0.445026], '16': [0, 0.0168605, 0.5, 0.0337209, 0.225131], '17': [24, 0.776163, 0.705934, 0.0639535, 0.186736], '18': [0, 0.344186, 0.651832, 0.104651, 0.434555], '19': [0, 0.665698, 0.764398, 0.159302, 0.467714], '20': [0, 0.0412791, 0.746946, 0.0825581, 0.495637], '21': [0, 0.260465, 0.725131, 0.14186, 0.549738], '22': [0, 0.131395, 0.818499, 0.167442, 0.363002], '23': [0, 0.943605, 0.688482, 0.112791, 0.619546]}

from sklearnex import patch_sklearn
patch_sklearn()

from collections import defaultdict
from copy import deepcopy
import numpy as np
import cv2

#dicky = {'0': [0, 0.0589844, 0.5375, 0.116406, 0.308333], "17":[21,22], '1': [0, 0.103125, 0.597222, 0.0640625, 0.294444], '2': [26, 0.197656, 0.744444, 0.0703125, 0.155556], '3': [26, 0.471484, 0.615278, 0.0257812, 0.0722222], '4': [5, 0.571875, 0.408333, 0.0484375, 0.141667], '5': [0, 0.388281, 0.532639, 0.046875, 0.234722], '6': [2, 0.725781, 0.502083, 0.090625, 0.165278], '7': [2, 0.664062, 0.479167, 0.05, 0.116667], '8': [0, 0.630469, 0.507639, 0.0296875, 0.168056], '9': [0, 0.059375, 0.700694, 0.11875, 0.579167], '10': [0, 0.167578, 0.645833, 0.0851562, 0.480556], '11': [5, 0.639453, 0.405556, 0.113281, 0.197222], '12': [0, 0.336328, 0.586806, 0.0757812, 0.348611], '13': [0, 0.252344, 0.607639, 0.0609375, 0.370833], '14': [0, 0.439844, 0.561806, 0.071875, 0.359722], '15': [7, 0.878906, 0.497917, 0.240625, 0.443056], '16': [0, 0.501172, 0.567361, 0.0617188, 0.329167]}
from copy import deepcopy
def reducedict(dicts,keepvalues):
    try:
        val = deepcopy(dicts)
        #print(val.values())
        for k,v in dicts.items():
            setting = set(v)
            if isinstance(keepvalues,list):
                length = len(keepvalues)
                for item in keepvalues:
                    if item not in setting:
                        length -= 1
                    if length == 0:
                        val.pop(k,None)
    except:
        return dicts
    
    return val

def createdict(dicky,imgsize=None):
    h,w,c = imgsize
    newdict = defaultdict(lambda: [])
    pascaldict = defaultdict(lambda: [])
    newerdict = defaultdict(lambda: [])
    for k,v in dicky.items():
        newlist = deepcopy(v)
        newlist[1] = int(v[1]*w)
        newlist[2] = int(v[2]*h)
        newlist[3] = int(v[3]*w)
        newlist[4] = int(v[4]*h)
        sp = [int(newlist[1] - (newlist[3]/2)), int(newlist[2] - (newlist[4]/2))]
        np = [tuple(sp)]
        np.append((int(newlist[1] + (newlist[3]/2)),int(newlist[2] + (newlist[4]/2))))
        sp.append(int(newlist[1] + (newlist[3]/2)))
        sp.append(int(newlist[2] + (newlist[4]/2)))
        if isinstance(v, list):
            if newdict[newlist[0]] == []:
                newdict[newlist[0]] = [newlist[1:]]
                pascaldict[newlist[0]] = [sp]
                newerdict[newlist[0]] = [np]
            else:
                newdict[newlist[0]].append(newlist[1:])
                pascaldict[newlist[0]].append(sp)
                newerdict[newlist[0]].append(np)
            pass
    return newdict,pascaldict,newerdict

def modifiedict(dicky,imgsize=None,pascalvoc=False):
    h,w,c = imgsize
    newdict = defaultdict(lambda: [])
    count = 0
    if pascalvoc == False:
        for k,v in dicky.items():
            newlist = deepcopy(v)
            newlist[0] = int(v[0])
            newlist[2] = int(v[2]*h)
            newlist[1] = int(v[1]*w)
            newlist[2] = int(v[2]*h)
            newlist[3] = int(v[3]*w)
            newlist[4] = int(v[4]*h)
            newdict[count] = newlist
            count += 1
        
        return newdict
    else:
        for k,v in dicky.items():
            newlist = deepcopy(v)
            newlist[0] = int(v[0])
            newlist[2] = int(v[2]*h)
            newlist[1] = int(v[1]*w)
            newlist[2] = int(v[2]*h)
            newlist[3] = int(v[3]*w)
            newlist[4] = int(v[4]*h)
            sp = [int(newlist[1] - (newlist[3]/2)), int(newlist[2] - (newlist[4]/2)),int(newlist[1] + (newlist[3]/2)),int(newlist[2] + (newlist[4]/2))]
            newdict[count] = sp
            count += 1
        return newdict
        

def createnewdict(dicky,imgsize=None):
    h,w,c = imgsize
    newdict = defaultdict(lambda: [])
    for k,v in dicky.items():
        newlist = deepcopy(v)
        newlist[1] = int(v[1]*w)
        newlist[2] = int(v[2]*h)
        newlist[3] = int(v[3]*w)
        newlist[4] = int(v[4]*h)
        sp = [int(newlist[1] - (newlist[3]/2)), int(newlist[2] - (newlist[4]/2))]
        np = [tuple(sp)]
        np.append((int(newlist[1] + (newlist[3]/2)),int(newlist[2] + (newlist[4]/2))))
        sp.append(int(newlist[1] + (newlist[3]/2)))
        sp.append(int(newlist[2] + (newlist[4]/2)))
        if isinstance(v, list):
            if newdict[newlist[0]] == []:
                newdict[newlist[0]] = [newlist[1:]]
            else:
                newdict[newlist[0]].append(newlist[1:])
                
    return newdict

#dicts = createnewdict(dicks,imgsize=(573, 860, 3))
#print(dicts)
def pascalvoc(dicky,imgsize=None):
    h,w,c = imgsize
    newdict = defaultdict(lambda: [])
    pascaldict = defaultdict(lambda: [])
    for k,v in dicky.items():
        newlist = deepcopy(v)
        newlist[1] = int(v[1]*w); newlist[2] = int(v[2]*h); newlist[3] = int(v[3]*w); newlist[4] = int(v[4]*h)
        sp = [int(newlist[1] - (newlist[3]/2)), int(newlist[2] - (newlist[4]/2))]
        sp.append(int(newlist[1] + (newlist[3]/2)))
        sp.append(int(newlist[2] + (newlist[4]/2)))
        if isinstance(v, list):
            if newdict[newlist[0]] == []:
                newdict[newlist[0]] = [newlist[1:]]
                pascaldict[newlist[0]] = [sp]
            else:
                newdict[newlist[0]].append(newlist[1:])
                pascaldict[newlist[0]].append(sp)

            pass
    return pascaldict

def createnewdict(dicky,imgsize=None):
    h,w,c = imgsize
    newdict = defaultdict(lambda: [])
    newerdict = defaultdict(lambda: [])
    for k,v in dicky.items():
        newlist = deepcopy(v)
        newlist[1] = int(v[1]*w)
        newlist[2] = int(v[2]*h)
        newlist[3] = int(v[3]*w)
        newlist[4] = int(v[4]*h)
        sp = [(int(newlist[1] - (newlist[3]/2)), int(newlist[2] - (newlist[4]/2))), (int(newlist[1] + (newlist[3]/2)),int(newlist[2] + (newlist[4]/2)))]
        if isinstance(v, list):
            if newdict[newlist[0]] == []:
                newdict[newlist[0]] = [newlist[1:]]
                newerdict[newlist[0]] = [sp]
            else:
                newdict[newlist[0]].append(newlist[1:])
                newerdict[newlist[0]].append(sp)
            pass
    return newerdict
#print(pascalvoc(dicks,imgsize=(573, 860, 3)))
#a,b,c = createdict(dicks,imgsize=(573, 860, 3))
#print(modifiedict(dicks,imgsize=(573, 860, 3),pascalvoc=True))
#print(modifiedict(dicks,imgsize=(573, 860, 3)))
#print(createdict(dicks,imgsize=(573, 860, 3))[0])
#print(createnewdict(dicks,imgsize=(573, 860, 3)))

def midpointdict(dicky,imgsize=None,instance="lst"):
    h,w,c = imgsize
    newdict = defaultdict(lambda: [])
    newerdict = defaultdict(lambda: [])
    for k,v in dicky.items():
        newlist = deepcopy(v)
        newlist[1] = int(v[1]*w)
        newlist[2] = int(v[2]*h)
        newlist[3] = int(v[3]*w)
        newlist[4] = int(v[4]*h)
        if instance != "lst":
            sp = [(int(newlist[1]),int(newlist[2]))]
        else:
            sp = [[int(newlist[1]),int(newlist[2])]]
        if isinstance(v, list):
            if newdict[newlist[0]] == []:
                newdict[newlist[0]] = [newlist[1:]]
                newerdict[newlist[0]] = sp
            else:
                newdict[newlist[0]].append(newlist[1:])
                newerdict[newlist[0]].append(sp[0])
            pass
    return newerdict

def convert1d(dict2d,imgsize=None):
    height,width,c = imgsize
    dicky = defaultdict(lambda: [])
    for k,v in dict2d.items():
        for item in v:
            #print(item)
            x,y = item
            i = x + width*y
            dicky[k].append(i)
            #x = i % width
            #y = int(i / width)
            #print(x,y)
    return dicky


def getdistance(dictis,neighbours,radius=1):
    from sklearn.neighbors import NearestNeighbors
    import itertools
    dictisq = [list(v) for k,v in dictis.items()]
    merged = np.array(list(itertools.chain.from_iterable(dictisq)))
    print()
    #print(merged)
    neigh = NearestNeighbors(n_neighbors=neighbours,n_jobs=-1)
    neigh.fit(merged)
    try:
        dist, neighs = neigh.kneighbors(merged, return_distance=True)
    except:
        return [],[]
    return dist, neighs

#print([34,240] in midpointdict(dicks,imgsize=(573, 860, 3))[0])


def getactualneigh(getdistances,modifiedict,threshold):
    a, b =  getdistances
    storeArr = []
    for count,c in enumerate(b):
        min_dist = a[count][1]
        max_dist = a[count][-1]
        if max_dist - min_dist < threshold:
            #print(a[count])
            storeArr.append(c.tolist())
    print()
    newdict = defaultdict(lambda: [])
    for counting,items in enumerate(storeArr):
        oldarr = []
        for count,item in enumerate(items):
            value = modifiedict[item]
            #oldvalue = modifiedict[item].pop(0)
            oldarr.append(value)
        newdict[counting] = oldarr
    return storeArr,newdict


#print()
#print(getactualneigh(getdistance(midpointdict(dicks,imgsize=(573, 860, 3))),modifiedict(dicks,imgsize=(573, 860, 3)),50)[1])
#print(pascalvoc(dicks,imgsize=(573, 860, 3)))



def allTogether(originalYolodict,listOfValues,imgsize,neighbours,threshold):
    yolodict = reducedict(originalYolodict,listOfValues)
    midpoint = midpointdict(yolodict,imgsize)
    modict = modifiedict(yolodict,imgsize)
    getting = getdistance(midpoint,neighbours)
    syn = getactualneigh(getting,modict,threshold)
    return syn

#print(allTogether(dicks)[1], "a")

def getnumpyArr(Arraydicts):
    storeArr, Arraydict = Arraydicts
    array = []
    arrays = []
    mincoordList = []
    maxcoordList = []
    for k in Arraydict:
        array.append(np.array(Arraydict[k]))
    items = None
    for item in array:
        items = np.copy(item)
        x_row = item[:,3]/2
        y_col = item[:,4]/2
        items[:,1] = item[:,1]-(item[:,3]/2)
        items[:,2] = item[:,2]-(item[:,4]/2)
        items[:,3] = item[:,1]+(item[:,3]/2)
        items[:,4] = item[:,2]+(item[:,4]/2)
        arrays.append(items)
        mincoordList.append(np.amin(items,axis=0)[1:3])
        maxcoordList.append(np.max(items,axis=0)[3:])
    print()
    return arrays,mincoordList,maxcoordList


#a,b,c= getnumpyArr(allTogether(dicks,neighbours=3,imgsize=(573, 860, 3),threshold=10))

#import cv2
#img = cv2.imread(r"C:\Users\Aravind\Desktop\04eb1893-28fa-42f5-bb85-f86ac8efea79.jpg", 10)



def drawonimage(img,mincoord,maxcoord,neighbours):
    for c in range(len(mincoord)):
        img = cv2.rectangle(img, tuple(mincoord[c]), tuple(maxcoord[c]), (36,255,12), 1)
        cv2.putText(img, f"With {neighbours} neighbours at {c}st rectangle", (tuple(mincoord[c])[0], tuple(mincoord[c])[1]-10), 
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (209, 80, 0, 255), 3, cv2.LINE_AA)
        print(f"Min coord is {mincoord[c]}, Max coord is {maxcoord[c]}")
    
    coordlist = zip(np.array(mincoord).tolist(),np.array(maxcoord).tolist())
    coording = [len(mincoord)]
    #cv2.imshow("image", img)
    #cv2.waitKey(0) 
    #closing all open windows 
    #cv2.destroyAllWindows() 
    return img,coordlist,coording



def finallytogether(originalimg,originalYolodict,listOfValues,imgsize,neighbours,threshold):
    together = allTogether(originalYolodict,listOfValues,imgsize,neighbours,threshold)
    _,b,c = getnumpyArr(together)
    _,coordlist,coording = drawonimage(originalimg,b,c,neighbours)
    for count,items in enumerate(list(coordlist)):
        print(f"This is da {count}th bounding box with {neighbours}neighbours with coords {items} ")
    return originalimg,coordlist,coording

#finallytogether(img,dicks,neighbours=7,imgsize=(573, 860, 3),threshold=100)

#img = drawonimage(img,b,c)



"""
from scipy.spatial import distance
import numpy as np

def compute_distance(midpoints):
    dicky = defaultdict()
    for k,v in midpoints.items():
        ving = len(v)
        dist = np.zeros((ving,ving))
        if len(v) > 1:
            for i in range(len(v)):
                for j in range(len( v)):
                    if i!=j:
                        dst = distance.euclidean(v[i], v[j])
                        dist[i][j]=dst
                    else:
                        dist[i][i] = None
        dicky[k] = dist
    #dist = dist.reshape(1,-1)
    #print
    return dicky

#dickj = compute_distance(dicts)


def checkArr(numpyArrs,midpointdict,threshold):
    dicks = defaultdict(lambda: [])
    for k,v in midpointdict.items():
        id = k
        numpyArr = numpyArrs[id]
        dicting = defaultdict(lambda: [])
        wrongdict = defaultdict(lambda: [])
        if len(numpyArr) > 1:
            for count,item in enumerate(numpyArr):
                if ((item <= threshold).sum() == 0).astype(np.int):
                    dicting[id].append(midpointdict[id][count])
                    dicks[id].append(midpointdict[id][count])
                if ((item <= threshold).sum() != 0).astype(np.int):
                    wrongdict[id].append(midpointdict[id][count])
            print(dicting[id])
            print(wrongdict[id])
            print(f"Wrong Coord + Right Coord == Total Coord-> dict by {len(midpointdict[id]) == len(dicting[id]) + len(wrongdict[id])}")
        #print(dicks)
    print(midpointdict)
    return dicks
#dickj = compute_distance(midpointdict(dicks,imgsize=(573, 860, 3))[0],len((midpointdict(dicks,imgsize=(573, 860, 3))[0])))
#print(checkArr(dickj,dicts,50))
"""
#print(compute_distance(midpointdict(dicks,imgsize=(573, 860, 3))[0],19))
#import cv2


# reads image 'opencv-logo.png' as grayscale
#img = cv2.imread(r"C:\Users\Aravind\Desktop\04eb1893-28fa-42f5-bb85-f86ac8efea79.jpg", 10)


#for k in c[0]:
#    sp,ep = k
    #print(k)
#    img = cv2.rectangle(img, sp, ep, (36,255,12), 1)
#image = cv2.rectangle(img, (528,242), (582,317), (36,255,12), 1)
#cv2.imshow("image", img)
#cv2.waitKey(0) 
#closing all open windows 
#cv2.destroyAllWindows() 
#if 'name' == 'main':
#    print("ys")"""
    
    
    
    

    
    
#print(allTogether(dicks,neighbours=6)[1], "a")
#print(getnumpyArr(allTogether(dicks,neighbours=3,imgsize=(573, 860, 3),threshold=10), 5)[2])
#print(np.array(asd[3]))



#image = cv2.rectangle(img, (0,217), (859,571), (36,255,12), 1)
#cv2.imshow("image", img)
#cv2.waitKey(0) 
#closing all open windows 
#cv2.destroyAllWindows()