import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore
from firebase_admin import storage
import time

def lingkus():
	certificateLoc = r"C:\Users\Aravind\OneDrive - Nanyang Technological University\Group\App Demo\anything-b35f8-firebase-adminsdk-tgzfy-547f3354b2.json"
	firebaseLoc = "anything-b35f8.appspot.com"
	cred = credentials.Certificate(certificateLoc)
	firebase_admin.initialize_app(cred, {'storageBucket': firebaseLoc})
	db = firestore.client()
	bucket = storage.bucket()
	#startiming = time()

	while True:
		doc_ref = db.collection(u'people')
		doc_ref.document(u'peoplecapacity').set({"0":0})
		time.sleep(5)
	return