#from typing import ItemsView
import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore
from firebase_admin import storage
#from PIL import Image

certificateLoc = r"C:\Users\Aravind\OneDrive - Nanyang Technological University\Group\App Demo\mozzie-a43b7-firebase-adminsdk-cs9iu-adfd71f8f8.json"
firebaseLoc = 'mozzie-a43b7.appspot.com'
cred = credentials.Certificate(certificateLoc)
firebase_admin.initialize_app(cred, {'storageBucket': firebaseLoc})
db = firestore.client()
bucket = storage.bucket()
#blob = bucket.blob(r"C:\Users\Aravind\OneDrive - Nanyang Technological University\Group\App Demo\yolov5\data\images\bus.jpg") #img_src)
#blob = bucket.blob("charangi.jpg") #img_src)
#blob.upload_from_filename(r"C:\Users\Aravind\Desktop\Camera\20210719_131456.jpg",content_type='image/jpg')
#blob = bucket.blob(r"C:\Users\Aravind\OneDrive - Nanyang Technological University\Group\App Demo\yolov5\data\images\bus.jpg") #img_src)
#blob2 = bucket.blob("charangi.txt") #img_src)

#with open(r"C:\Users\Aravind\OneDrive - Nanyang Technological University\Group\App Demo\yolov5\runs\detect\exp29\labels\0_0.txt", 'rb') as my_file:
#    blob2.upload_from_file(my_file)
#blob2.upload_from_filename(r"C:\Users\Aravind\OneDrive - Nanyang Technological University\Group\App Demo\yolov5\runs\detect\exp29\labels\0_0.txt",content_type='image/jpg')
#doc_ref.add(r"C:\Users\Aravind\OneDrive - Nanyang Technological University\Group\App Demo\yolov5\data\images\bus.jpg")

while True:
    string = input()
    if string == "q":
        break
    elif string == "r":
        blob3 = bucket.blob("charangi.jpg")
        print("HI")
        blob3.download_to_filename(r"C:\Users\Aravind\OneDrive - Nanyang Technological University\Group\App Demo\yolov5\rangis.jpg")
        doc_ref = db.collection(u'users').document(u'alovelacing')
        doc = doc_ref.get()
        print(doc.to_dict())
